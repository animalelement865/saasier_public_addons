# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created: Mon Nov  3 14:22:02 2014
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
import sys
from settings import Ui_settings
from enroll import Ui_enroll
import pinmenu_s
import pinmenu_e
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(QtGui.QMainWindow):


    def __init__(self):

        QtGui.QMainWindow.__init__(self)
        self.setupUi(self)


    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(1024, 600)

        self.centralWidget = QtGui.QWidget(MainWindow)

        self.centralWidget.setStyleSheet("""
	.QWidget {
	background-image: url(res/images/background.jpg);
	}
	""")
        self.centralWidget.setObjectName(_fromUtf8("centralWidget"))
        self.enroll_btn = QtGui.QPushButton(self.centralWidget)
        self.enroll_btn.setGeometry(QtCore.QRect(250, 370, 131, 51))
        self.enroll_btn.setObjectName(_fromUtf8("enroll_btn"))
        self.settings_btn = QtGui.QPushButton(self.centralWidget)
        self.settings_btn.setGeometry(QtCore.QRect(643, 370, 131, 51))
        self.settings_btn.setObjectName(_fromUtf8("settings_btn"))
        MainWindow.setCentralWidget(self.centralWidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.enroll_btn.clicked.connect(self.enroll_menu)
        self.settings_btn.clicked.connect(self.settings_menu)
        self.settings_btn.setStyleSheet("""

        QPushButton {

        background-color: white;
        border-style: outset;
        border-width: 1px;
        border-color: black;
        font: bold 14px;
        border-radius: 10px;


        }

        QPushButton:pressed {
        background-color: grey;
        border-style: inset;
        }

        """)

        self.enroll_btn.setStyleSheet("""

        QPushButton {

        background-color: white;
        border-style: outset;
        border-width: 1px;
        border-color: black;
        font: bold 14px;
        border-radius: 10px;


        }

        QPushButton:pressed {
        background-color: grey;
        border-style: inset;
        }

        """)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow", None))
        self.enroll_btn.setText(_translate("MainWindow", "Enroll", None))
        self.settings_btn.setText(_translate("MainWindow", "Settings", None))

    def enroll_menu(self):
        self.enr = pinmenu_e.Ui_pinmenu()
        self.enr.show()

    def settings_menu(self):


        self.sett = pinmenu_s.Ui_pinmenu()
        self.sett.show()



if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    ex = Ui_MainWindow()
    ex.show()

    sys.exit(app.exec_())